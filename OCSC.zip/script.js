document.getElementById("loginBtn").addEventListener("click", function() {
    window.location.href = "/login.html";
});
